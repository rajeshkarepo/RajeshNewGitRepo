﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace TabDelimiterDemo
{
    class Program
    {
        //public static string AddDoubleQuotes(this string value)
        //{
        //    return "\"" + value + "\"";
        //}
        static void Main(string[] args)
        {
            //string s = @"This is a ""quoted"" string.";
            //int start = s.IndexOf('"');
            //int end = s.IndexOf('"');
            //var val = s.Substring(start);
            string str = @"""How to add doublequotes""";
           
            var startIndex = str.IndexOf('"');
            var strr = str.Substring(startIndex + 1, str.Length - 2);
            //var withOutQotes = withQuotes.Split(",");
            // string stra = "Would \"you\" like to have responses to your \"questions\" sent to you via email?";
           // var stringArray = str1.Split(',');

            DataTable dt = new DataTable();
            using (TextReader tr = File.OpenText(@"D:\Workspace\Projects\TabDelimiterDemo\TabDelimitedOutputFile.csv"))
            {
                var file = @"D:\Workspace\Projects\TabDelimiterDemo\TabDelimitedOutputFile.csv";
                // Print out all the values
                StringBuilder builder = new StringBuilder();

                string line;
                int i = 0;
                while ((line =tr.ReadLine()) != null)
                {
                   
                   if (line.Contains("\""))
                    {
                        var index = line.IndexOf('"');
                        var subStr = line.Substring(index + 1, str.Length - 2);
                        
                        if (subStr.Contains(","))
                        {
                            subStr = subStr.Replace(","," ");
                        }
                        line = "";

                        foreach (var item in strs)
                        {
                            line = line + item;
                        }
                    }
                  
                    string[] items = line.Split(',');

                    //string row = string.Join(",",items);
                       builder.AppendLine(items.ToString()); 
                      dt.Columns.Add(new DataColumn("Column" + i++, typeof(string)));
                    
                    //using (var stream = File.CreateText(file))
                    //{
                    //    stream.WriteLine(builder.ToString());
                    //}
                    //dt.Rows.Add(items);
                }
            }
            
            Console.ReadKey();
        }
    }
}
